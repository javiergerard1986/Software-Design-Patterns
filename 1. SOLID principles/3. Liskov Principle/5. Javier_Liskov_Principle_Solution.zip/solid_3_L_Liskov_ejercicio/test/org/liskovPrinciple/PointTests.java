package org.liskovPrinciple;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.liskovPrinciple.Point2D;
import org.liskovPrinciple.Point3D;

public class PointTests {

	private final Point2D point2D = new Point2D(3,5);
	private final List<Point2D> test_points_2D = Arrays.asList(
			                                         new Point2D(2,3), 
			                                         new Point2D(3,5), 
			                                         new Point2D(4,3),
			                                         new Point2D(3,4),
			                                         new Point2D(2,2)
			                                         );
	
	private final Point2D point3D = new Point3D(3,5,2);
	
	
	@Test
	public void ponits2D_are_the_same_only_if_distance_is_equals_0() {
		
		for (Point2D point: test_points_2D) {
			Assert.assertEquals("Test for " + point2D + " y " + point,
					point2D.equals(point), 
					point2D.distance(point) == 0);
		}
	}
	
	@Test
	public void ponits2D_are_the_same_only_if_distance_is_equals_0_make_fail() {
		for (Point2D point: test_points_2D) {
			Assert.assertEquals("Test for " + point3D + " y " + point,
										point3D.distance(point) == 0);
		}
	}
	
}
