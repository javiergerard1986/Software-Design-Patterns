package org.formacion.di.negocio;

public interface Inventario {

	public int numeroProductos(String tienda, String producto);

}
