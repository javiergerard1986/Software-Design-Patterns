package org.dependencyInversion.persistence;

import java.util.HashMap;
import java.util.Map;

public class DataBase {

	// Data Base
	public static Map<String, Map<String, Integer>> stocks = new HashMap<>();
	
	static {
		Map<String, Integer> stockNorthStore = new HashMap<>();
		stockNorthStore.put("lamp",399);
		stockNorthStore.put("table",501);
		
		stocks.put("North Store", stockNorthStore);
	}
	


}
