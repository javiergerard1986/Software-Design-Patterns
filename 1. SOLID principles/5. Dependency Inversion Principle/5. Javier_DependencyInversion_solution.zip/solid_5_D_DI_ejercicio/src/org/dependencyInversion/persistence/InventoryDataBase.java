package org.dependencyInversion.persistence;

import org.dependencyInversion.businesslogic.IStockController;

public class InventoryDataBase implements IStockController{
	
	// Method to request data from the database
	public int getStock(String store, String productName) {
		return DataBase.stocks.get(store).get(productName);
	}
}
