package org.dependencyInversion.businesslogic;

public interface IStockController {

	public int getStock(String store, String productName);
	
}
