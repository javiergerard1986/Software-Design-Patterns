package org.dependencyInversion.businesslogic;

public class StockController {

	private IStockController stockController;
	
	public StockController(IStockController inventory) {
		this.stockController = inventory;
	}

	public boolean needsReplanish (String store, String productName) {
		int actualStock = this.stockController.getStock(store, productName);
		
		return actualStock < productName.length() * 100;
	}

}
