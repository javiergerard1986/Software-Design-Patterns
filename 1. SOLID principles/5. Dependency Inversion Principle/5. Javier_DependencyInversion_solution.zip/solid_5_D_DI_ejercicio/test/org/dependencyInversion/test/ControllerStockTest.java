package org.dependencyInversion.test;

import org.dependencyInversion.businesslogic.StockController;
import org.dependencyInversion.persistence.InventoryDataBase;
import org.junit.Assert;
import org.junit.Test;

public class ControllerStockTest {

	@Test
	public void test_controller_stock() {
		StockController stockController = new StockController(new InventoryDataBase());
		
		Assert.assertFalse(stockController.needsReplanish("North Store", "table"));
		Assert.assertTrue(stockController.needsReplanish("North Store", "lamp"));

	}

}
