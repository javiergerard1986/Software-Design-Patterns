package org.singleResponsability;

import java.util.stream.Collectors;

public class Reporter {

	private Recommender recomendador = new Recommender();
	
	public String exportRecommendedFilms (Client client) {
		
		return recomendador.recommendations(client).stream()
		      .map(p -> (p.getTitle() + "," + p.getDirector() + "," + p.getGenre()))
		      .collect(Collectors.joining("\n"));
	}
}
