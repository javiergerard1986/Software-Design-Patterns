package org.singleResponsability;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DataBase {

	private static final String TERROR_GENRE = "Terror";
	private static final String BELIC_GENRE = "Belic";
	
	public static final String DIRECTOR_SPIELBERG = "Spielberg";
	
	public static final Film ET = new Film("ET", TERROR_GENRE, DIRECTOR_SPIELBERG);
	public static final Film RYAN_SOLDIER_RESCUE = new Film("Ryan soldier rescue", BELIC_GENRE, DIRECTOR_SPIELBERG);
	
	public static final Film [] ALL_FILMS = { ET, RYAN_SOLDIER_RESCUE};
	
	public static final Client JHON = new Client("John", ET);
	
	public static Map<String, List<Film>> FILMS_BY_DIRECTOR = Arrays.stream(ALL_FILMS)
			.collect(Collectors.groupingBy(Film::getDirector));
			
	
}
