package org.singleResponsability;

import java.util.Arrays;
import java.util.List;

public class Client {
 
	private final String name;
	private final List<Film> favorites;
	
	public Client (String name, Film ... favorites) {
		this.name = name;
		this.favorites = Arrays.asList(favorites);
	}

	public String getName() {
		return this.name;
	}

	public List<Film> getFavorites() {
		return this.favorites;
	}
	
	
}
