package org.singleResponsability;

public class Film {

	private final String title;
	private final String genre;
	private final String director;
	
	public Film(String title, String genre, String director) {
		this.title = title;
		this.genre = genre;
		this.director = director;
	}

	public String getTitle() {
		return this.title;
	}

	public String getGenre() {
		return this.genre;
	}

	public String getDirector() {
		return this.director;
	}

	@Override
	public String toString() {
		return "Film [title=" + this.title + ", genre=" + this.genre + ", director=" + this.director + "]";
	}
	
	
}
