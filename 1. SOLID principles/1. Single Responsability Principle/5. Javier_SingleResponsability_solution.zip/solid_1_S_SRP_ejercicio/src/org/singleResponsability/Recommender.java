package org.singleResponsability;

import java.util.ArrayList;
import java.util.List;

public class Recommender {

	public List<Film> recommendations (Client client) {
		
		List<Film> recommendedFilms = new ArrayList<>();
		
		for (Film favorite: client.getFavorites()) {
				recommendedFilms.addAll(DataBase.FILMS_BY_DIRECTOR.get(favorite.getDirector()));
		}
		recommendedFilms.removeAll(client.getFavorites());
		
		return recommendedFilms;
	}
	
}
