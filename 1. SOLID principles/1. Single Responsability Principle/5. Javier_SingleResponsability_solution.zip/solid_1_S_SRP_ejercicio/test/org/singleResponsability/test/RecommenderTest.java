package org.singleResponsability.test;

import java.util.List;

import org.junit.Test;
import org.singleResponsability.DataBase;
import org.singleResponsability.Film;
import org.singleResponsability.Recommender;
import org.singleResponsability.Reporter;
import org.junit.Assert;

public class RecommenderTest {

	@Test
	public void test() {
		Recommender r = new Recommender();
		
		List<Film> recomended = r.recommendations(DataBase.JHON);
		
		Assert.assertFalse(recomended.contains(DataBase.ET));
	}
	
	@Test 
	public void format_test() {
		Reporter csvExport = new Reporter();
		
		String csv = csvExport.exportRecommendedFilms(DataBase.JHON);
		
		String expectedResult = "Ryan soldier rescue,Spielberg,Belic";
		Assert.assertEquals(expectedResult, csv);

	}

}
