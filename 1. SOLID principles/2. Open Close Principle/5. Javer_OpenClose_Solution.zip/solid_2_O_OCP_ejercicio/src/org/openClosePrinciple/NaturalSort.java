package org.openClosePrinciple;

import java.util.List;

public class NaturalSort implements ISort{

	@Override
	public List<Integer> sort(List<Integer> primesList) {
		return primesList;
	}

}
