package org.openClosePrinciple;

import java.util.ArrayList;
import java.util.List;

public class PrimesGenerator {

	private ISort sort;
	
	public ISort getSort() {
		return this.sort;
	}
	
	public PrimesGenerator() {
		
	}
	
	public PrimesGenerator(ISort sort) {
		this.sort = sort;
	}
	
	public List<Integer> primes (int limit) {
		
		List<Integer> primes = new ArrayList<>();
		for (int i = 2; i < limit; i++) {
			if (isPrime(i)) {
				primes.add(i);
			}
		}
		return this.sort.sort(primes);

	}
	
	private boolean isPrime (int candidate) {
		for (int i = 2; i < candidate; i++) {
			if (candidate % i == 0) {
				return false;
			}
		}
		
		return true;
	}
}
