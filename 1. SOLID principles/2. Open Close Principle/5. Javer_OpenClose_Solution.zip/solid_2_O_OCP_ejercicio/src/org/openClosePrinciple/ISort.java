package org.openClosePrinciple;

import java.util.List;

public interface ISort {

	public List<Integer> sort(List <Integer> primesList);
	
}
