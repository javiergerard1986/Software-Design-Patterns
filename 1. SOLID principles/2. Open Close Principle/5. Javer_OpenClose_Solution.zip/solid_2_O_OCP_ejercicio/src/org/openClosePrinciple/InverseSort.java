package org.openClosePrinciple;

import java.util.ArrayList;
import java.util.List;

public class InverseSort implements ISort{

	@Override
	public List<Integer> sort(List<Integer> primesList) {
		
		List<Integer> invertedList = new ArrayList<>();
		System.out.println(primesList.size());
		for(int x = primesList.size(); x >= 1 ; x--) {
			invertedList.add(primesList.get(x - 1));
		}
		return invertedList;
	}

}
