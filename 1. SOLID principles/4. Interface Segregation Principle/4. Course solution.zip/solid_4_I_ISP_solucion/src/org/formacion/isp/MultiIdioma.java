package org.formacion.isp;

public interface MultiIdioma extends Procesador{

	boolean correcto(Idioma idioma);

}