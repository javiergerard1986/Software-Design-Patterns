package org.formacion.isp;

public interface Procesador {

	void nueva(String palabra);

	String texto();

}