package org.interfaceSegreationPrincipleTests;

import static org.junit.Assert.*;

import org.interfaceSegregationPrinciple.CorrectorTextProcessor;
import org.interfaceSegregationPrinciple.Language;
import org.interfaceSegregationPrinciple.SimpleTextProcessor;
import org.junit.Test;


public class TextProcessorTest {

	@Test
	public void test_simple() {
		
		SimpleTextProcessor simpleProcessor = new SimpleTextProcessor();
		
		simpleProcessor.addWord("No");
		simpleProcessor.addWord("matter");
		simpleProcessor.addWord("the");
		simpleProcessor.addWord("hortography");
		
		assertEquals("No matter the hortography", simpleProcessor.getText());
	}
	
	@Test
	public void test_con_idioma() {
		
		CorrectorTextProcessor correctorTextProcessor = new CorrectorTextProcessor();
		
		correctorTextProcessor.addWord("Tengo");
		correctorTextProcessor.addWord("hambre");
		
		assertEquals("Tengo hambre", correctorTextProcessor.getText());
		
		assertTrue(correctorTextProcessor.validateText(Language.ES));
	}
}
