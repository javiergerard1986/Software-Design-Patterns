package org.interfaceSegregationPrinciple;

import java.util.Arrays;
import java.util.List;

public enum Language {
	
	EN ("I","am","angry"), 
	ES ("tengo","hambre"), 
	CA ("tenc", "fam");
	
	List<String> dictionary;

	private Language(String ... words) {
		this.dictionary = Arrays.asList(words);
	}
	

}
