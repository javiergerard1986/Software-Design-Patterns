package org.interfaceSegregationPrinciple;

public interface ITextValidator {

	public boolean validateText (Language language);
	
}
