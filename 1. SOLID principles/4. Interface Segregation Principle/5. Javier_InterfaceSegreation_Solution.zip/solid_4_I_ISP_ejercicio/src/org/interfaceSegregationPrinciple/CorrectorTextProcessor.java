package org.interfaceSegregationPrinciple;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CorrectorTextProcessor implements ITextProcessor, ITextValidator{

	private List<String> text = new ArrayList<>();
	
	public CorrectorTextProcessor() {
		this.text = new ArrayList<>();
	}
	
	@Override
	public boolean validateText(Language language) {
		for (String palabra: this.text) {
			if (!language.dictionary.contains(palabra.toLowerCase())) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void addWord(String word) {
		this.text.add(word);
	}

	@Override
	public String getText() {
		return text.stream().collect(Collectors.joining(" "));
	}

}
