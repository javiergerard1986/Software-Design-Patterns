package org.interfaceSegregationPrinciple;

public interface ITextProcessor {
	
	public void addWord (String word);
	
	public String getText();
	
}
