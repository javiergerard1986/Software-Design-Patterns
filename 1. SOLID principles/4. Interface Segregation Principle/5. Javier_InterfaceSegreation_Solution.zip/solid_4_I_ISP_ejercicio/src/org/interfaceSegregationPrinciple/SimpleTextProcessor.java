package org.interfaceSegregationPrinciple;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SimpleTextProcessor implements ITextProcessor {

	private List<String> text;
	
	public SimpleTextProcessor(){
		this.text = new ArrayList<>();
	}	
	
	@Override
	public void addWord(String word) {
		this.text.add(word);
	}
	
	@Override
	public String getText() {
		return this.text.stream().collect(Collectors.joining(" "));
	}

}
