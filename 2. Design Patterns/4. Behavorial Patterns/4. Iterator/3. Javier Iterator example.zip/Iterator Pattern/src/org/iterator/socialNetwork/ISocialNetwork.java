package org.iterator.socialNetwork;

import org.iterator.iterators.IProfileIterator;

public interface ISocialNetwork {

	IProfileIterator createFriendsIterator(String profileEmail);

    IProfileIterator createCoworkersIterator(String profileEmail);
	
}
