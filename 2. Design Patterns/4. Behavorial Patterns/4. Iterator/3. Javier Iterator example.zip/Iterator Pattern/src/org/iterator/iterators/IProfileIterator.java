package org.iterator.iterators;

import org.iterator.profile.Profile;

public interface IProfileIterator {

	boolean hasNext();

	Profile getNext();

	void reset();
	
}
