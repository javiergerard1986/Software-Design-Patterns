package org.formacion.command;

public interface Pedido {
	
	int peso();

}
