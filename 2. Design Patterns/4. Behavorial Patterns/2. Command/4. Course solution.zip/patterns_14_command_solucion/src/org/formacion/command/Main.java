package org.formacion.command;

public class Main {

}
