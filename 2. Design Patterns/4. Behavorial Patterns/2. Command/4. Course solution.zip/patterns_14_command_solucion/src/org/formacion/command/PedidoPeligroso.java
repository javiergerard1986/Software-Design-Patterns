package org.formacion.command;

public interface PedidoPeligroso extends Pedido {

     String instrucciones();

}
