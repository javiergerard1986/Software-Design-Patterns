package org.formacion.command;

public interface TratamientoPedido {

	boolean tratar();
}
