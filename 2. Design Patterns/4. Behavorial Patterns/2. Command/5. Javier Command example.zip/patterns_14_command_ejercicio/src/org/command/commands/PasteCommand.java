package org.command.commands;

import org.command.editor.Editor;

public class PasteCommand extends Command{

    public PasteCommand(Editor editor) {
        super(editor);
    }

    @Override
    public boolean execute() {
        if (this.editor.clipboard == null || this.editor.clipboard.isEmpty()) return false;

        backup();
        this.editor.textField.insert(this.editor.clipboard, this.editor.textField.getCaretPosition());
        return true;
    }
	
}
