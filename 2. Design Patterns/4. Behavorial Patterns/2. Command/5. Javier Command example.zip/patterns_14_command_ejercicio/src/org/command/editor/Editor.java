package org.command.editor;

import javax.swing.*;
import java.awt.*;
import javax.swing.BoxLayout;

import org.command.commands.Command;
import org.command.commands.CommandHistory;
import org.command.commands.CopyCommand;
import org.command.commands.CutCommand;
import org.command.commands.PasteCommand;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Editor {

	public JTextArea textField;
	public String clipboard;
	private CommandHistory history = new CommandHistory();
	
	public void init() {
		JFrame frame = new JFrame("Text editor (type & use buttons, Luke!)");
	    JPanel content = new JPanel();
	    frame.setContentPane(content);
	    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	    content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
	    textField = new JTextArea();
	    textField.setLineWrap(true);
	    content.add(textField);
	    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
	    JButton copyButton = new JButton("Ctrl+C");
	    JButton cutButton = new JButton("Ctrl+X");
	    JButton pasteButton = new JButton("Ctrl+V");
	    JButton undoButton = new JButton("Ctrl+Z");
	    Editor editor = this;
	    
	    // Add command to the "Copy" button
	    copyButton.addActionListener(new ActionListener() {
	    	@Override
	        public void actionPerformed(ActionEvent e) {
	    		executeCommand(new CopyCommand(editor));
	        }
	    });
	    
	    // Add command to the "Cut" button
	    cutButton.addActionListener(new ActionListener() {
	    	@Override
	        public void actionPerformed(ActionEvent e) {
	            executeCommand(new CutCommand(editor));
	        }
	        });
	    
	    // Add command to the "Paste" button
	    pasteButton.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            executeCommand(new PasteCommand(editor));
	        }
	    });
	    
	    // Add command to the "Undo" button
	    undoButton.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            undo();
	        }
	    });
	        
	    buttons.add(copyButton);
	    buttons.add(cutButton);
	    buttons.add(pasteButton);
	    buttons.add(undoButton);
	    content.add(buttons);
	    
	    frame.setSize(450, 200);
	    frame.setLocationRelativeTo(null);
	    frame.setVisible(true);
	}
	 
	private void executeCommand(Command command) {
	    if(command.execute()) {
	        history.push(command);
	    }
	}

	private void undo() {
	    if (history.isEmpty()) return;
	    Command command = history.pop();
	    if (command != null) {
	        command.undo();
	    }
	}
	
}
