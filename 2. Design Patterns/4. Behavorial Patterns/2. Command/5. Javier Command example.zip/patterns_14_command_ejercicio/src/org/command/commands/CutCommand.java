package org.command.commands;

import org.command.editor.Editor;

public class CutCommand extends Command{

    public CutCommand(Editor editor) {
        super(editor);
    }

    @Override
    public boolean execute() {
        if (this.editor.textField.getSelectedText().isEmpty()) return false;
        this.backup();
        String source = this.editor.textField.getText();
        this.editor.clipboard = this.editor.textField.getSelectedText();
        this.editor.textField.setText(cutString(source));
        return true;
    }

    private String cutString(String source) {
        String start = source.substring(0, this.editor.textField.getSelectionStart());
        String end = source.substring(this.editor.textField.getSelectionEnd());
        return start + end;
    }
	
}
