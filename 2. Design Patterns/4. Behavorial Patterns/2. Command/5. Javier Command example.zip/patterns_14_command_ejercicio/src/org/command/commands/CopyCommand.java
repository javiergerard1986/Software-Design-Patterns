package org.command.commands;

import org.command.editor.Editor;

public class CopyCommand extends Command {

    public CopyCommand(Editor editor) {
        super(editor);
    }

    @Override
    public boolean execute() {
        this.editor.clipboard = this.editor.textField.getSelectedText();
        return false;
    }
}
