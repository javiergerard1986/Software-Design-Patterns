package org.command.commands;

import org.command.editor.Editor;


public abstract class Command {
    
	protected Editor editor;
    protected String backup;

    public Command(Editor editor) {
        this.editor = editor;
    }

    public void backup() {
        this.backup = this.editor.textField.getText();
    }

    public void undo() {
        this.editor.textField.setText(this.backup);
    }

    public abstract boolean execute();
}