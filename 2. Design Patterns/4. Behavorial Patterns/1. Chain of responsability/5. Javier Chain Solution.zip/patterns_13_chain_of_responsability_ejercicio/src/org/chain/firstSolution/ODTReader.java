package org.chain.firstSolution;

public class ODTReader extends Reader{

	public ODTReader() {
		super("ODT");
	}
	
	@Override
	public boolean accept(Document document) {
		return document.getExtension() == this.getType();
	}
	
}
