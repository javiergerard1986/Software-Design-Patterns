package org.chain.secondSolution;

public class DOCReader extends Reader{

	public DOCReader() {
		super("DOC");
	}
	
	@Override
	public boolean accept(Document document) {
		return document.getExtension() == this.getType();
	}
	
}
