package org.chain.firstSolution;

public class Document {

	private String extension;
	private String content;
	
	public String getExtension(){
		return this.extension;
	}
	
	public void setExtension(String extension) {
		this.extension = extension;
	}
	
	public String getContent() {
		return this.content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
	public Document(String extension, String content) {
		this.extension = extension;
		this.content = content;
	}
	
}
