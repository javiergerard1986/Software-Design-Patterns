package org.chain.secondSolution;

public abstract class Reader implements IReader{
	
	private IReader nextReader;
	private String type;
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public IReader getReader() {
		return this.nextReader;
	}
	
	@Override
	public void setNextReader(IReader reader) {
		this.nextReader = reader;
	}
	
	public Reader(String type) {
		this.type = type;
	}
	
	@Override
	public String processContent(Document document) {
		String content = "";
		if(this.accept(document)) {
			content = document.getContent();
		}else{
			if(this.nextReader != null) {
				return this.nextReader.processContent(document);
			}
		}
		return content;
	}
	
}
