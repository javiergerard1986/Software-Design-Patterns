package org.chain.firstSolution;

public interface IReader {

	boolean accept(Document document);
	
	String processContent(Document document);

}
