package org.chain.secondSolution;

public class ODTReader extends Reader{

	public ODTReader() {
		super("ODT");
	}
	
	@Override
	public boolean accept(Document document) {
		return document.getExtension() == this.getType();
	}
	
}
