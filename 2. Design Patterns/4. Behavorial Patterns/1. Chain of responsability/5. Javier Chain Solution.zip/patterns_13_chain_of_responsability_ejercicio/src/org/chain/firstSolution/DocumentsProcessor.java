package org.chain.firstSolution;

import java.util.ArrayList;
import java.util.List;

public class DocumentsProcessor {
	
	private List<IReader> readers;
	
	public DocumentsProcessor() {
		this.readers = new ArrayList<IReader>();
		this.readers.add(new DOCReader());
		this.readers.add(new ODTReader());
		this.readers.add(new PDFReader());
	}
	
	public String processDocuments(List<Document> documents) {
		
		String processedText = "";
		
		// Iterate over each document in order to process it
		for(Document doc: documents){
			// Iterate over each reader to find which of them will process the document
			for(IReader reader: this.readers) {
				if(reader.accept(doc)) {
					processedText += doc.getContent();
				}
			}
			processedText += "\n";
		}
		
		return processedText;
		
	}
	
}
