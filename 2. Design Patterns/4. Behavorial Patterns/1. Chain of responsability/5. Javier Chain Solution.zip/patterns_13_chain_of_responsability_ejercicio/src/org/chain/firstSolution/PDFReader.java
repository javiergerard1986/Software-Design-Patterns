package org.chain.firstSolution;

public class PDFReader extends Reader{

	public PDFReader() {
		super("PDF");
	}
	
	@Override
	public boolean accept(Document document) {
		return document.getExtension() == this.getType();
	}
	
}
