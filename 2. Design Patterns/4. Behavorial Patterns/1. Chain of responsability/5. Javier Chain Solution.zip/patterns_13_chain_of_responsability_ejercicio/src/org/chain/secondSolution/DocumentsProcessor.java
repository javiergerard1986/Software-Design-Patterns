package org.chain.secondSolution;

import java.util.List;

public class DocumentsProcessor {
	
	private IReader reader;
	
	public void setReader(IReader reader) {
		this.reader = reader;
	}
	
	public String processDocuments(List<Document> documents) {
		
		String processedText = "";
		
		// Iterate over each document in order to process it
		for(Document doc: documents){
			// Call the Document Processor reader to trigger the processContent across the chain
			processedText += this.reader.processContent(doc);
			processedText += "\n";
		}
		
		return processedText;
		
	}
	
}
