package org.chain.firstSolution;

public abstract class Reader implements IReader{
	
	private String type;
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public Reader(String type) {
		this.type = type;
	}
	
	@Override
	public String processContent(Document document) {
		return document.getContent();
	}
	
}
