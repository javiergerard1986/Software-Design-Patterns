package org.chain.secondSolution;

public interface IReader {

	IReader getReader();
	
	void setNextReader(IReader reader);
	
	boolean accept(Document document);
	
	String processContent(Document document);
	
}
