package org.chain.tests;


import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.chain.firstSolution.Document;
import org.chain.firstSolution.DocumentsProcessor;
import org.junit.Test;

public class ChainTestsFirstSolution {

	private DocumentsProcessor docProc = new DocumentsProcessor();
	
	@Test
	public void test() {
		List<Document> documents = Arrays.asList(
				 new Document("DOC", "Fucking DOC file"),
				 new Document("PDF", "Fucking PDF file"),
				 new Document("ODT", "Fucking ODT file")
				 );
		
		String expectedResult = "Fucking DOC file\n" + 
				"Fucking PDF file\n" + 
				"Fucking ODT file\n";
		
		assertEquals(this.docProc.processDocuments(documents), expectedResult);
	}

}
