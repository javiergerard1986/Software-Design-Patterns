package org.chain.tests;


import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.chain.secondSolution.Document;
import org.chain.secondSolution.DocumentsProcessor;
import org.chain.secondSolution.IReader;
import org.chain.secondSolution.PDFReader;
import org.chain.secondSolution.ODTReader;
import org.junit.Test;

public class ChainTestsSecondSolution {

	private DocumentsProcessor docProc = new DocumentsProcessor();
	
	public void init(){
		IReader pdfReader = new PDFReader();
		pdfReader.setNextReader(new ODTReader());
		this.docProc.setReader(pdfReader);
	}
	
	@Test
	public void test() {
		
		// Initialize Database
		this.init();
		
		List<Document> documents = Arrays.asList(
				 new Document("DOC", "Fucking DOC file"),
				 new Document("ODT", "Fucking ODT file"),
				 new Document("PDF", "Fucking PDF file")
				 );
		
		String expectedResult = "\nFucking ODT file\n" + 
				"Fucking PDF file\n";
		
		assertEquals(this.docProc.processDocuments(documents), expectedResult);
	}

}
