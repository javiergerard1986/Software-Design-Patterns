
package org.decorator.secondExample;

public class WithCream extends ExtrasCoffeeDecorator{

	public WithCream(ICoffee coffee) {
		super(coffee);	
	}
	
	@Override
	public String getDescription() {
		return super.getDescription() + " with cream";
	}

	@Override
	// Add milk increments $27 the price
	public double getPrice() {
		return super.getPrice() + 27;
	}
	
}
