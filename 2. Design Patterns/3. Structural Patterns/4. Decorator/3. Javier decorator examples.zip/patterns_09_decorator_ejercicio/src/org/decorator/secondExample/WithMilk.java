package org.decorator.secondExample;

public class WithMilk extends ExtrasCoffeeDecorator {
	
	public WithMilk (ICoffee coffee) {
		super(coffee);
	}

	@Override
	public String getDescription() {
		return super.getDescription() + " with milk";
	}

	@Override
	// Add milk increments 20% the coffee price
	public double getPrice() {
		return super.getPrice() * 1.2;
	}
	
}
