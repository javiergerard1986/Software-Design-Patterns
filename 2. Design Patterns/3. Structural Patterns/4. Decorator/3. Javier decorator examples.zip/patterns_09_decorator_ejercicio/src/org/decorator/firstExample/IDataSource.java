package org.decorator.firstExample;

public interface IDataSource {

	// The "Component" interface defines operations that the decorates could alter
	void writeData(String data);
	
	String readData();
	
}
