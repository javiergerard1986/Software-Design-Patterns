package org.decorator.secondExample;

public class ExtrasCoffeeDecorator implements ICoffee{

	protected ICoffee coffee;

    public ExtrasCoffeeDecorator(ICoffee coffee) {
        this.coffee = coffee;
    }

    @Override
    public String getDescription() {
    	return this.coffee.getDescription();
    }

    @Override
    public double getPrice() {
        return this.coffee.getPrice();
    }
    
}
