package org.decorator.secondExample;

public interface ICoffee {

	public String getDescription();
	
	public double getPrice();
	
}
