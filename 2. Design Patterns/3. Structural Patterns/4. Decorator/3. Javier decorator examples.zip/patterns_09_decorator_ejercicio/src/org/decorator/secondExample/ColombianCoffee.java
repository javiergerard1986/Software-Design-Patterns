package org.decorator.secondExample;

public class ColombianCoffee implements ICoffee{

	private double price = 90;
	
	@Override
	public String getDescription() {
		return "Colombian coffee";
	}

	@Override
	public double getPrice() {
		return this.price;
	}
	
}
