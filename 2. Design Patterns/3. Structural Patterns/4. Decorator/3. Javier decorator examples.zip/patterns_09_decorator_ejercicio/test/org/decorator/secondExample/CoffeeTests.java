package org.decorator.secondExample;

import static org.junit.Assert.*;

import org.junit.Test;

public class CoffeeTests {

	@Test
	public void test() {
		
		ICoffee colombianCoffee = new WithMilk(new ColombianCoffee());
		
		// Colombian coffee price = $90, with milk (add %20 = $108)
		assertTrue("Colombian coffee with milk has an invalid price!!!", colombianCoffee.getPrice() == 108);
		assertTrue("Colombian coffee must contain milk in the description", colombianCoffee.getDescription().contains("milk"));
		assertFalse("Colombian coffee must not contain cream in the description", colombianCoffee.getDescription().contains("cream"));
		
		colombianCoffee = new WithCream(new ColombianCoffee());
		
		// Colombian coffee price = $90, with cream (+ $27) = $117
		assertTrue("Colombian coffee with cream has an invalid price!!!", colombianCoffee.getPrice() == 117);
		assertTrue("Colombian coffee must contain cream in the description", colombianCoffee.getDescription().contains("cream"));
		assertFalse("Colombian coffee must not contain milk in the description", colombianCoffee.getDescription().contains("milk"));
		
		colombianCoffee = new WithCream(new WithMilk(new ColombianCoffee()));
		
		// Colombian coffee price = $90, with milk (add %20 = $108), with cream (+ $27) = $135
		assertTrue("Colombian coffee with cream has an invalid price!!!", colombianCoffee.getPrice() == 135);
		assertTrue("Colombian coffee must contain cream in the description", colombianCoffee.getDescription().contains("cream"));
		assertTrue("Colombian coffee must contain milk in the description", colombianCoffee.getDescription().contains("milk"));
		
	}

}
