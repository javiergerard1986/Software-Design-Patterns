package org.decorator.secondExample;

public class CoffeeDemo {

	public static void main(String[] args) {
		
		ICoffee colombianCoffeeWithMilk = new WithCream(new WithMilk(new ColombianCoffee()));
		System.out.println(colombianCoffeeWithMilk.getDescription());
		System.out.println(colombianCoffeeWithMilk.getPrice());
	}
	
}
