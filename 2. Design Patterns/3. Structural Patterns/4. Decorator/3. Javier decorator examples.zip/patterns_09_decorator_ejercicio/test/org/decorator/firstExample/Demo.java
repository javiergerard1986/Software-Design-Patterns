package org.decorator.firstExample;

import org.decorator.firstExample.CompressionDecorator;
import org.decorator.firstExample.DataSourceDecorator;
import org.decorator.firstExample.EncryptionDecorator;
import org.decorator.firstExample.FileDataSource;
import org.decorator.firstExample.IDataSource;

public class Demo {

	public static void main(String[] args) {
        String salaryRecords = "Name,Salary\nJohn Smith,100000\nSteven Jobs,912000";
        DataSourceDecorator encoded = new EncryptionDecorator(
                                         new CompressionDecorator(
                                             new FileDataSource("out/OutputDemo.txt")));
        encoded.writeData(salaryRecords);
        IDataSource plain = new FileDataSource("out/OutputDemo.txt");

        System.out.println("- Input ----------------");
        System.out.println(salaryRecords);
        System.out.println("- Encoded --------------");
        System.out.println(plain.readData());
        System.out.println("- Decoded --------------");
        System.out.println(encoded.readData());
    }
	
}
