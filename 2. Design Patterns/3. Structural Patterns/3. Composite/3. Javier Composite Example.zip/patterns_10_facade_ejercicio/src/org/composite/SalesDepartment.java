package org.composite;

public class SalesDepartment extends BaseDepartment{

	private int bono;
	
	public SalesDepartment(int id, String name, int budget, int bono) {
		super(id, name, budget);
		this.bono = bono;
	}
	
	public int getBono() {
		return this.bono;
	}
	
	public void setBono(int bono) {
		this.bono = bono;
	}
	
}
