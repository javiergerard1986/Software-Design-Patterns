package org.composite;

public abstract class BaseDepartment implements IDepartment{

	protected int id;
	protected String name;
	protected int budget;
	
	public BaseDepartment(int id, String name, int budget) {
		this.id = id;
		this.name = name;
		this.budget = budget;
	}
	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBudget() {
		return this.budget;
	}

	public void setBudget(int budget) {
		this.budget = budget;
	}
	
	public void printName() {
		System.out.println("Department name: " + this.name);
	}

}
