package org.composite;

import java.util.ArrayList;
import java.util.List;

public class HeadDepartment implements IDepartment{
	
	private List<IDepartment> childDepartments;
	
	public HeadDepartment() {
		this.childDepartments = new ArrayList<IDepartment>();
	}
	
	public HeadDepartment(List<IDepartment> childDepartments) {
		this();
		this.childDepartments = childDepartments;
	}
	
	public void addDepartment(IDepartment department) {
		this.childDepartments.add(department);
	}	
	
	public void removeDepartment(IDepartment department) {
		this.childDepartments.remove(department);
	}

	@Override
	public int getBudget() {
		int budget = 0;
		
		for(int x = 0; x < this.childDepartments.size(); x++) {
			budget += this.childDepartments.get(x).getBudget();
		}
		
		return budget;
	}

	@Override
	public void printName() {
		System.out.println("Department composed by the next sub-departments: ");
		for(int x = 0; x < this.childDepartments.size(); x++) {
			this.childDepartments.get(x).printName();
		}
	}
	
}
