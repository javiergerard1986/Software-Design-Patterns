package org.composite.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.composite.FinancialDepartment;
import org.composite.HeadDepartment;
import org.composite.IDepartment;
import org.composite.MarketingDepartment;
import org.composite.SalesDepartment;
import org.junit.Test;

public class CompositeTests {

	private IDepartment financialDep;
	private IDepartment salesDep;
	private IDepartment marketingDep;
	private IDepartment headDep;
	private IDepartment companyDeps;
	
	public void init(){
		this.financialDep = new FinancialDepartment(1, "Finances Department", 4500, 15);
		this.salesDep = new SalesDepartment(2, "Sales Department", 5500, 7000);
		this.marketingDep = new MarketingDepartment(3, "Marketing Department", 3000, "Think big!");
		
		List<IDepartment> subDepartments = new ArrayList<IDepartment>();
		subDepartments.add(this.financialDep);
		subDepartments.add(this.salesDep);
		this.headDep = new HeadDepartment(subDepartments);
		
		List<IDepartment> companyDepartments = new ArrayList<IDepartment>();
		companyDepartments.add(this.marketingDep);
		companyDepartments.add(this.headDep);
		this.companyDeps = new HeadDepartment(companyDepartments);
	}
	
	
	@Test
	public void composite_test() {
		// Initialize database
		this.init();
		
		// Validate department budgets
		assertEquals("Head Department budget is not the expected. Sales ($5500) + Finances ($4500) = $10000", this.headDep.getBudget(), 10000);
		assertEquals("Marketing Department budget is not the expected. Marketing budget = $3000", this.marketingDep.getBudget(), 3000);
		assertEquals("The budget for all the company departments must be $13000. Sales ($5000) + Finances ($4500) + Marketing ($3000) = $13000", this.companyDeps.getBudget(), 13000);
		
		// Print department names
		System.out.println("------------------------------");
		System.out.println("Single Department name: ");
		System.out.println("------------------------------");
		this.marketingDep.printName();
		
		System.out.println("------------------------------");
		System.out.println("Composed Department name: ");
		System.out.println("------------------------------");
		this.headDep.printName();
		
		System.out.println("------------------------------");
		System.out.println("Composed Department name: Single Department + Composed department ");
		System.out.println("------------------------------");
		this.companyDeps.printName();
	}

}
