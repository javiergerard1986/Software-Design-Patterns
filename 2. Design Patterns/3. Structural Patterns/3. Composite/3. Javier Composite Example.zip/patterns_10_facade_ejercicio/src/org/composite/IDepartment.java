package org.composite;

public interface IDepartment {
	
	int getBudget();
	void printName();
	
}
