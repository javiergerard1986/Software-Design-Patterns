package org.composite;

public class FinancialDepartment extends BaseDepartment{

	private int amountOfPeople;
	
	public FinancialDepartment(int id, String name, int budget, int amountOfPeople) {
		super(id, name, budget);
		this.amountOfPeople = amountOfPeople;
	}
	
	public int getAmountOfPeople() {
		return this.amountOfPeople;
	}
	
	public void setAmountOfPeople(int amountOfPeople) {
		this.amountOfPeople = amountOfPeople;
	}
		
}
