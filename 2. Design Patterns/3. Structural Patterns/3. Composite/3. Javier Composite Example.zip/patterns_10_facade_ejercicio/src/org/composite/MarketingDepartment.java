package org.composite;

public class MarketingDepartment extends BaseDepartment{

	private String mainCampaign;
	
	public MarketingDepartment(int id, String name, int budget, String mainCampaign) {
		super(id, name, budget);
		this.mainCampaign = mainCampaign;
	}
	
	public String getMainCampaign() {
		return this.mainCampaign;
	}
	
	public void setBudget(String mainCampaign) {
		this.mainCampaign = mainCampaign;
	}
	
}
