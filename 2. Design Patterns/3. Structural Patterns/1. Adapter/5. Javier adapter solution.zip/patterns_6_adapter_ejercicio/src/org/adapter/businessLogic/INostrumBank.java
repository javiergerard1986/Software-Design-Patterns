package org.adapter.businessLogic;

public interface INostrumBank {

	void transaction(String client, int quantity);
	
	Integer getClientStatus(String client);
	
}
