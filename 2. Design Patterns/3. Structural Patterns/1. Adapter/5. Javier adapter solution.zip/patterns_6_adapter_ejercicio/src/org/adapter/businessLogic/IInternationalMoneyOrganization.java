package org.adapter.businessLogic;

public interface IInternationalMoneyOrganization {

	void transfer(int quantity, String client);
	
	/** Must returns 0 if the client does not exist */
	int state(String client);

}
