package org.adapter.businessLogic;

public class APIAdapter extends NostrumBankImplementation implements IInternationalMoneyOrganization {

	@Override
	public void transfer(int quantity, String client) {
		this.transaction(client, quantity);
	}

	@Override
	public int state(String client) {
		Integer clientState = this.getClientStatus(client);
		
		if(clientState == null) {
			return 0;
		}
		
		return clientState;
	}
	
}
