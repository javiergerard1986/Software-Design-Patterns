package org.adapter.businessLogic;

public class APIAdapter implements IInternationalMoneyOrganization {

	private INostrumBank nostrumbank;
	
	public APIAdapter() {
		this.nostrumbank = new NostrumBankImplementation();
	}
	
	@Override
	public void transfer(int quantity, String client) {
		this.nostrumbank.transaction(client, quantity);
	}

	@Override
	public int state(String client) {
		Integer clientState = this.nostrumbank.getClientStatus(client);
		
		if(clientState == null) {
			return 0;
		}
		
		return clientState;
	}
	
}
