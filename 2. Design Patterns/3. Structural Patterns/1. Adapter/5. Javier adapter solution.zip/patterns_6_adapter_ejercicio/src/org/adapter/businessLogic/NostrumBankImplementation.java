package org.adapter.businessLogic;

import java.util.HashMap;
import java.util.Map;

public class NostrumBankImplementation implements INostrumBank {

	private final Map<String, Integer> clientsDatabase = new HashMap<>();
	
	@Override
	public void transaction(String client, int quantity) {
		Integer accountAmount = getClientStatus(client);
		if (accountAmount == null) {
			accountAmount = 0;
		} 
     	this.clientsDatabase.put(client,  accountAmount + quantity);
	}

	@Override
	public Integer getClientStatus(String client) {
		return this.clientsDatabase.get(client);
	}

}
