package org.adapter.tests;

import org.adapter.businessLogic.APIAdapter;
import org.adapter.businessLogic.IInternationalMoneyOrganization;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class InternationMoneyTests {

	private IInternationalMoneyOrganization service;
	
	@Before
	public void init() {
		this.service = new APIAdapter();
	}
	
	@Test
	public void client_does_not_exist_test() {
		Assert.assertEquals(0, this.service.state("Client_does_not_exist"));
	}

	@Test
	public void operations_with_new_client_test() {
		String client = "John Perez";
		this.service.transfer(100, client);
		Assert.assertEquals(100, this.service.state(client));
		this.service.transfer(-70, client);
		Assert.assertEquals(30, this.service.state(client));
	}
}
