package org.flyweight.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.flyweight.Player;
import org.flyweight.Team;
import org.junit.jupiter.api.Test;

class FlyweightTests {

	Team team;
	Player player1;
	Player player2;
	Player player3;
	Player player4;
	
	public void initDatabase() {
		
		this.team = new Team("Defensor");
		this.player1 = new Player(this.team, "Gerard", 1, "Goalkeeper");
		this.player2 = new Player(this.team, "Moreira", 5, "Defense");
		this.player3 = new Player(this.team, "Lora", 7, "Medium");
		this.player4 = new Player(this.team, "Farias", 9,"Ofense");
		this.team.addPlayer(player1);
		this.team.addPlayer(player2);
		this.team.addPlayer(player3);
		this.team.addPlayer(player4);
		
	}
	
	@Test
	void test() {
		
		// Load team
		this.initDatabase();
		
		// Draw team shirt template
		System.out.println("--------------------------------");
		System.out.println("Team shirt template");
		System.out.println("--------------------------------");
		System.out.println(this.team.drawTeamShirtTemplate());
		System.out.println("---");
		System.out.println("---");
		System.out.println("--------------------------------");
		System.out.println("Team players shirts");
		System.out.println("--------------------------------");
		// Draw team players shirts
		for(int x = 0; x < this.team.getPlayers().size(); x++) {
			Player currentPlayer = this.team.getPlayers().get(x);
			System.out.println("--------------------------------");
			System.out.println(currentPlayer.getName() + " shirt:");
			System.out.println("--------------------------------");
			System.out.println(currentPlayer.drawShirt());
			System.out.println("---");
			System.out.println("---");
		}
	}

}
