package org.flyweight;

import java.util.ArrayList;
import java.util.List;

public class Team {

	private String name;
	private Shirt shirt;
	private List<Player> players;
	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Player> getPlayers() {
		return this.players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	
	public Team(String name) {
		this.name = name;
		this.players = new ArrayList<Player>();
	}
	
	public void addPlayer(Player player){
		this.players.add(player);
	}
	
	public void removePlayer(Player player){
		this.players.remove(player);
	}
	
	public static String drawShirt(String name, int number){
		return Shirt.draw(name, number);
	}
	
	public static String drawTeamShirtTemplate(){
		return Shirt.drawShirtTemplate();
	}
	
}
