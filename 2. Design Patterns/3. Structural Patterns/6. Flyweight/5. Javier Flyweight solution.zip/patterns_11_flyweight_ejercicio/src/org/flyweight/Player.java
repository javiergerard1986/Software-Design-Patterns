package org.flyweight;

public class Player {

	private Team team;
	private String name;
	private int number;
	private String position;
	
	public Player(Team team, String name, int number, String position) {
		this.team = team;
		this.name = name;
		this.number = number;
		this.position = position;
	}
	
	public Team getTeam() {
		return this.team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumber() {
		return this.number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getPosition() {
		return this.position;
	}
	
	public void setPosition(String position) {
		this.position = position;
	}

	public String drawShirt() {
 		return this.team.drawShirt(this.name, this.number);
 	}

}
