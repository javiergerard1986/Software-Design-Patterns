package org.formacion.flyweight;

public class Jugador2 {

 	public String dibuja() {
 		return Camiseta.UNICA.dibuja("2");
 	}

}
