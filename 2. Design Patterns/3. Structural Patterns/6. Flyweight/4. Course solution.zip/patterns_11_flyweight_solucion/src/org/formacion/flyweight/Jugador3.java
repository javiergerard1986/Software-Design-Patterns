package org.formacion.flyweight;

public class Jugador3 {

 	public String dibuja() {
 		return Camiseta.UNICA.dibuja("3");
 	}

}
