package org.formacion.flyweight;

public class Jugador1 {


 	public String dibuja() {
 		return Camiseta.UNICA.dibuja("1");
 	}

}
