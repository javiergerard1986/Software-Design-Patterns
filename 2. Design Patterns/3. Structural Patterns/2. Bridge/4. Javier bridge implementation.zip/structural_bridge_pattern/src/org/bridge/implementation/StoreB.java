package org.bridge.implementation;

public class StoreB implements IStoreImplementation{

	@Override
	public String getProductDescription(String product) {
		return "Product description ...";
	}

	@Override
	public void pruchaseProduct(String productName, int quantity) {
		System.out.println("Purchase product");
	}

	@Override
	public void buyBox(String productName, int productsByBox) {
		System.out.println("Buy product");
	}
	
}
