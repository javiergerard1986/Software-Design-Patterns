package org.bridge.abstraction;

public interface IOnlineSeller {

	String getProductDescription(String productName);
	
}
