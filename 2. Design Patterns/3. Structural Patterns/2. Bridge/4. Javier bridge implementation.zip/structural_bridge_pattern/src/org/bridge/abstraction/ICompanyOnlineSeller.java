package org.bridge.abstraction;

public interface ICompanyOnlineSeller extends IOnlineSeller {

	void purchaseProduct(String productName, int quantityPerBox, int boxesQuantity); 

}
