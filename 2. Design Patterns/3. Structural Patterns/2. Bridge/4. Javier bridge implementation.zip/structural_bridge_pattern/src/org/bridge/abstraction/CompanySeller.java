package org.bridge.abstraction;

import org.bridge.implementation.IStoreImplementation;

/**
 * This class is the bridge between the ICompanyOnlineSeller interface and the store implementations
 */
public class CompanySeller implements ICompanyOnlineSeller {
	
	private IStoreImplementation store;

	public CompanySeller(IStoreImplementation store) {
		this.store = store;
	}

	// Scenario where the method is already implemented in the Store class and it does not need any adaption
	@Override
	public String getProductDescription(String productName) {
		return this.store.getProductDescription(productName);
	}
	
	
	/**
	 * Complex scenario where we need to adapt the differences between the 2 APIs.
	 */
	@Override
	public void purchaseProduct(String productName, int quantityPerBox, int boxesQuantity){
		
		for (int i = 0; i < boxesQuantity; i++) {
			this.store.buyBox(productName, quantityPerBox);
		}
		
	}

}
