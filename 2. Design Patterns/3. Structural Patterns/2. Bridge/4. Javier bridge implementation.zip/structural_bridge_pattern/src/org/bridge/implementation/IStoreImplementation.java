package org.bridge.implementation;

// This interface will group the common functionality for all the stores
public interface IStoreImplementation {
	
	public String getProductDescription(String product);
	
	void pruchaseProduct(String productName, int quantity); 

	void buyBox(String productName, int productsByBox);
	
}
