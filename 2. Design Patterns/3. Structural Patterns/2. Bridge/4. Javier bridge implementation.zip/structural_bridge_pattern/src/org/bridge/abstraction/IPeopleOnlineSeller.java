package org.bridge.abstraction;

public interface IPeopleOnlineSeller extends IOnlineSeller {

	void purchaseProduct(String productName, int quantity); 

}
