package org.bridge.abstraction;

public class PeopleSeller implements IPeopleOnlineSeller{

	@Override
	public String getProductDescription(String productName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void purchaseProduct(String productName, int quantity) {
		// TODO Auto-generated method stub
		
	}

}
