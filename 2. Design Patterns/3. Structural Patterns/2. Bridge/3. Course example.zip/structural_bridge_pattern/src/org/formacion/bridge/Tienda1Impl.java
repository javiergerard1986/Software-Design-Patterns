package org.formacion.bridge;

public class Tienda1Impl implements TiendaImpl {

	@Override
	public String descripcionProducto(String producto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void compraProducto(String nombre, int cantidad) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void compraCaja(String nombre, int numeroProductosEnCaja) {
		// TODO Auto-generated method stub
		
	}


}
