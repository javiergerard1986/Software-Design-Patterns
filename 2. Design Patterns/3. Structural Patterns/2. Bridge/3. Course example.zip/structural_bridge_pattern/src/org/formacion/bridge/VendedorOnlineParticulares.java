package org.formacion.bridge;

public interface VendedorOnlineParticulares extends VendedorOnline {

	void compraProducto (String nombre, int cantidad); 

}
