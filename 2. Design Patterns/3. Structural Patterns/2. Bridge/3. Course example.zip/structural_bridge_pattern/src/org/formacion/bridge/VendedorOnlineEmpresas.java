package org.formacion.bridge;

public interface VendedorOnlineEmpresas extends VendedorOnline {

	void compraProducto (String nombre, int cantidadPorCaja, int cajas); 

}
