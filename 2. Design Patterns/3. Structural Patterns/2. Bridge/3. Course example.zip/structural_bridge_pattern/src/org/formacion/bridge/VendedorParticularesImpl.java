package org.formacion.bridge;

public class VendedorParticularesImpl implements VendedorOnlineParticulares {

	@Override
	public String descripcionProducto(String producto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void compraProducto(String nombre, int cantidad) {
		// TODO Auto-generated method stub
		
	}

}
