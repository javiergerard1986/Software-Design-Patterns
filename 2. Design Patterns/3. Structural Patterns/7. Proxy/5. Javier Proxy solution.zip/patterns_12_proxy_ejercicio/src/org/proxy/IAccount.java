package org.proxy;

public interface IAccount {

	String getClient();

	int getMoney();

	void transfer(int money);

}