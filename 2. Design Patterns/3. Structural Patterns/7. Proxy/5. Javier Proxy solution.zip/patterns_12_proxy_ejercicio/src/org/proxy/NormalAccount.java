package org.proxy;

public class NormalAccount implements IAccount {

	private final String client;
	private int money;
	
	public NormalAccount(String client) {
		this.client = client;
		this.money = 0;
	}

	@Override
	public String getClient() {
		return this.client;
	}

	@Override
	public int getMoney() {
		return this.money;
	}

	@Override
	public void transfer (int money) {
		this.money += money;
	}
	
}
