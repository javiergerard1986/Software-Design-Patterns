package org.proxy;

public class PossitiveAccount implements IAccount{
	
	private NormalAccount account;
	
	public PossitiveAccount(String client) {
		this.account = new NormalAccount(client);
	}
	
	@Override
	public String getClient() {
		return this.account.getClient();
	}

	@Override
	public int getMoney() {
		return this.account.getMoney();
	}

	@Override
	public void transfer(int money) {
		if((this.getMoney() + money) > -1) {
			this.account.transfer(money);
		}
	}

}
