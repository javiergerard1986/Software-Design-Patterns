package org.proxy.tests;

import static org.junit.Assert.*;

import org.junit.Test;
import org.proxy.NormalAccount;
import org.proxy.PossitiveAccount;

public class ProxyTests {

	@Test
	public void normal_account_test() {
		NormalAccount normalAccount = new NormalAccount("Perez");
		assertEquals("Perez", normalAccount.getClient());
		assertEquals(0, normalAccount.getMoney());

		normalAccount.transfer(10);
		assertEquals(10, normalAccount.getMoney());

		normalAccount.transfer(-20);
		assertEquals(-10, normalAccount.getMoney());
	}

	@Test
	public void possitive_account_test() {
		PossitiveAccount possitiveAcccount = new PossitiveAccount("Lora");
		assertEquals("Lora", possitiveAcccount.getClient());
		assertEquals(0, possitiveAcccount.getMoney());

		possitiveAcccount.transfer(10);
		assertEquals(10, possitiveAcccount.getMoney());

		// The transaction will not be executed because the balance will be a negative number
		possitiveAcccount.transfer(-20);
		assertEquals(10, possitiveAcccount.getMoney());
	}

	
}
