package org.facade.tests;

import static org.junit.Assert.*;

import org.facade.CommunicationPreferences;
import org.facade.CommunicationService;
import org.facade.ConfigurationService;
import org.facade.DataBase;
import org.facade.Facade;
import org.facade.FidelityService;
import org.junit.Before;
import org.junit.Test;

public class FacadeTests {

	private Facade facade;
	private String clientName = "Antonia";
	private String clientEmail = "antonia@email.com";
	
	@Before
	public void init() {
		DataBase.INSTANCE.clear();
		facade = Facade.getInstance();
	}
	
	@Test
	public void create_express_registration_withoutFacade_test() {

		// Required code to register a new client
		ConfigurationService configService = new ConfigurationService();
		FidelityService fidelityService = new FidelityService();
		CommunicationService communicationService = new CommunicationService();

		fidelityService.createCard(clientName, FidelityService.Type.BASIC);
		configService.addEmail(clientName, clientEmail);
		communicationService.setPreferences(clientName, new CommunicationPreferences(false, true, true));
		
		assertEquals(DataBase.INSTANCE.getCard(clientName), FidelityService.Type.BASIC);
		assertEquals(DataBase.INSTANCE.getEmail(clientName), clientEmail);
		CommunicationPreferences preferences = DataBase.INSTANCE.getPreferences(clientName);
		assertNotNull(preferences);
		assertFalse("Do not recive daily email", preferences.isDailyEmail());
		assertTrue("Recive weekly email", preferences.isWeeklyEmail());
		assertTrue("Recive html email", preferences.isHtmlEmail());
		
	}
	
	@Test
	public void test_facade() {
		
		this.facade.expressRegistration(clientName, clientEmail);
		
		assertEquals(DataBase.INSTANCE.getCard(clientName), FidelityService.Type.BASIC);
		assertEquals(DataBase.INSTANCE.getEmail(clientName), clientEmail);
		CommunicationPreferences preferences = DataBase.INSTANCE.getPreferences(clientName);
		assertNotNull(preferences);
		assertFalse("Do not recive daily email", preferences.isDailyEmail());
		assertTrue("Recive weekly email", preferences.isWeeklyEmail());
		assertTrue("Recive html email", preferences.isHtmlEmail());
		
	}

}
