package org.facade;

public class Facade {

	private static Facade INSTANCE;
	ConfigurationService configService;
	FidelityService fidelityService;
	CommunicationService communicationService;
	
	
	private Facade() {
		this.configService = new ConfigurationService(); 
		this.fidelityService = new FidelityService();
		this.communicationService = new CommunicationService();
	}
	
	public synchronized static Facade getInstance() {
		if(INSTANCE == null) {
			if(INSTANCE == null) {
				INSTANCE = new Facade();
			}
		}
		return INSTANCE;
	}
	
	public void expressRegistration(String clientName, String email) {
		this.fidelityService.createCard(clientName, FidelityService.Type.BASIC);
		this.configService.addEmail(clientName, email);
		this.communicationService.setPreferences(clientName, new CommunicationPreferences(false, true, true));
	}
	
}
