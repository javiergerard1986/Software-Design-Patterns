package org.facade;


public class ConfigurationService {

	public void addEmail(String client, String email) {
		DataBase.INSTANCE.setEmail(client, email);
	}

}
