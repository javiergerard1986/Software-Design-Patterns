package org.facade;

import java.util.HashMap;
import java.util.Map;

public enum DataBase {

	INSTANCE;
	
	private Map<String, String> emails = new HashMap<>();
    private Map<String, FidelityService.Type> cards = new HashMap<>();
    private Map<String, CommunicationPreferences> preferences = new HashMap<>();
	
	
	public void clear() {
		this.emails.clear();
		this.cards.clear();
		this.preferences.clear();
	}
	
	public void setEmail(String client, String email) {
		this.emails.put(client, email);
	}
	
	public String getEmail(String client) {
		return emails.get(client);
	}
	
	public void addCard (String client, FidelityService.Type type) {
		this.cards.put(client, type);
	}
	
	public FidelityService.Type getCard (String client) {
		return this.cards.get(client);
	}
	
	public void setPreferences (String client, CommunicationPreferences preferences) {
		this.preferences.put(client, preferences);
	}
	
	public CommunicationPreferences getPreferences (String client) {
		return this.preferences.get(client);
	}
	
}
