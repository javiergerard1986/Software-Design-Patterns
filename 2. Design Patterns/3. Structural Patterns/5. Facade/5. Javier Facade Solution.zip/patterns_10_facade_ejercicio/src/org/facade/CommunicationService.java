package org.facade;

public class CommunicationService {

	public void setPreferences (String client, CommunicationPreferences preferences) {
		DataBase.INSTANCE.setPreferences(client, preferences);
	}

}
