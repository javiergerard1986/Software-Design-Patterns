package org.facade;

public class FidelityService {

	public enum Type { BASIC, PREMIUM, VIP }
	
	public void createCard(String client, Type type) {
		DataBase.INSTANCE.addCard(client, type);
	}

}
