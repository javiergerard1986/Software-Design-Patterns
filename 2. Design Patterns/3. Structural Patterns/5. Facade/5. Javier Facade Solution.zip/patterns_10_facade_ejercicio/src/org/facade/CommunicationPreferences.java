package org.facade;

public class CommunicationPreferences {

	private final boolean dailyEmail;
	private final boolean weeklyEmail;
	private final boolean htmlEmail;
	
	public CommunicationPreferences(boolean dailyEmail, boolean weeklyEmail, boolean htmlEmail) {
		this.dailyEmail = dailyEmail;
		this.weeklyEmail = weeklyEmail;
		this.htmlEmail = htmlEmail;
	}

	public boolean isDailyEmail() {
		return this.dailyEmail;
	}

	public boolean isWeeklyEmail() {
		return this.weeklyEmail;
	}

	public boolean isHtmlEmail() {
		return this.htmlEmail;
	}
	
}
