package org.formacion.prototype.solution;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.formacion.prototype.enums.MEAT;
import org.formacion.prototype.enums.SIZE;
import org.formacion.prototype.enums.TOY;
import org.formacion.prototype.objects.ChildHamburger;
import org.formacion.prototype.objects.Hamburger;
import org.formacion.prototype.objects.Kitchen;
import org.formacion.prototype.objects.RoyalHamburger;
import org.formacion.prototype.enums.BREAD;
import org.formacion.prototype.enums.CAVIAR;
import org.junit.Test;

public class TestHamburguerPrototype {

	Kitchen kitchen = new Kitchen();
	List<Hamburger> burgers = new ArrayList<>();
	
	@Test
	public void child_hambuger_test() {
			
		// Base Child Burger contains: MEAT.BOVINE, SIZE.SMALL, BREAD.NORMAL, TOY.BUZZ
		ChildHamburger childBurger = kitchen.createChildBurger();
		
		assertEquals(MEAT.BOVINE, childBurger.getMeat());
		assertEquals(SIZE.SMALL, childBurger.getSize());
		assertEquals(BREAD.NORMAL, childBurger.getBread());
		assertEquals(TOY.BUZZ, childBurger.getToy());
		assertNotEquals(TOY.PRINCESS, childBurger.getToy());
		
		ChildHamburger modifiedChildBurger = (ChildHamburger) childBurger.cloneBurger()
																	.setSize(SIZE.BIG);
		modifiedChildBurger.setToy(TOY.BALL);
		
		assertEquals(MEAT.BOVINE, modifiedChildBurger.getMeat());
		assertEquals(SIZE.BIG, modifiedChildBurger.getSize());
		assertEquals(BREAD.NORMAL, modifiedChildBurger.getBread());
		assertEquals(TOY.BALL, modifiedChildBurger.getToy());
		assertNotEquals(TOY.BUZZ, modifiedChildBurger.getToy());
		
	}
	
	@Test
	public void royal_hambuger_test() {
		
		// Base Royal Burger contains: MEAT.CHIKEN, SIZE.BIG, BREAD.WITH_SEEDS, CAVIAR.BELUGA 
		RoyalHamburger royalBurger = kitchen.createRoyalBurger();
		
		assertEquals(MEAT.CHIKEN, royalBurger.getMeat());
		assertEquals(SIZE.BIG, royalBurger.getSize());
		assertEquals(BREAD.WITH_SEEDS, royalBurger.getBread());
		assertEquals(CAVIAR.BELUGA, royalBurger.getCaviar());
		assertNotEquals(CAVIAR.CARUGA, royalBurger.getCaviar());
		
		RoyalHamburger modifiedRoyalBurger = (RoyalHamburger) royalBurger.cloneBurger()
																	.setSize(SIZE.EXTRA_BIG);
		modifiedRoyalBurger.setCaviar(CAVIAR.CARUGA);
		
		assertEquals(MEAT.CHIKEN, modifiedRoyalBurger.getMeat());
		assertEquals(SIZE.EXTRA_BIG, modifiedRoyalBurger.getSize());
		assertEquals(BREAD.WITH_SEEDS, modifiedRoyalBurger.getBread());
		assertEquals(CAVIAR.CARUGA, modifiedRoyalBurger.getCaviar());
		assertNotEquals(CAVIAR.BELUGA, modifiedRoyalBurger.getCaviar());
		
	}
	
}
