package org.formacion.prototype.enums;

public enum MEAT {
	BOVINE, CHIKEN
}