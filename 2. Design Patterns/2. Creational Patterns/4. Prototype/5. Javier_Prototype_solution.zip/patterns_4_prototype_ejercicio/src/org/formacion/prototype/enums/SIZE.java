package org.formacion.prototype.enums;

public enum SIZE {
	SMALL, MEDIUM, BIG, EXTRA_BIG
}
