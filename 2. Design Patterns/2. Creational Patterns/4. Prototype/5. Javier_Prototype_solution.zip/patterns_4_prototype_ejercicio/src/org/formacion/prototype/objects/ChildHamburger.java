package org.formacion.prototype.objects;

import org.formacion.prototype.enums.BREAD;
import org.formacion.prototype.enums.MEAT;
import org.formacion.prototype.enums.SIZE;
import org.formacion.prototype.enums.TOY;

public class ChildHamburger extends Hamburger{

	private TOY toy;
	
	public ChildHamburger() {}
	
	public ChildHamburger(MEAT meat, SIZE size, BREAD bread, TOY toy) {
		super(meat, size, bread);
		this.toy = toy;
	}
	
	public ChildHamburger(ChildHamburger target) {
		super(target);
		if(target != null) {
			this.toy = target.toy;
		}
	}

	public TOY getToy() {
		return this.toy;
	}

	public Hamburger setToy(TOY toy) {
		this.toy = toy;
		return this;
	}

	@Override
	public Hamburger cloneBurger() {
		return new ChildHamburger(this);
	}
	
}
