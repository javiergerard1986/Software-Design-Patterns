package org.formacion.prototype.enums;

public enum BREAD {
	NORMAL, WITH_SEEDS
}
