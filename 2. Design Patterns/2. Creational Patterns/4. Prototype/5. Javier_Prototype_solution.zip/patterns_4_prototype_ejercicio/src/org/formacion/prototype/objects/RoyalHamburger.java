package org.formacion.prototype.objects;

import org.formacion.prototype.enums.BREAD;
import org.formacion.prototype.enums.CAVIAR;
import org.formacion.prototype.enums.MEAT;
import org.formacion.prototype.enums.SIZE;

public class RoyalHamburger extends Hamburger{
	
	private CAVIAR caviar;
	
	public RoyalHamburger() {}
	
	public RoyalHamburger(MEAT meat, SIZE size, BREAD bread, CAVIAR caviar) {
		super(meat, size, bread);
		this.caviar = caviar;
	}
	
	public RoyalHamburger(RoyalHamburger target) {
		super(target);
		if(target != null) {
			this.caviar = target.caviar;
		}
	}
	
	public CAVIAR getCaviar() {
		return this.caviar;
	}

	public Hamburger setCaviar(CAVIAR caviar) {
		this.caviar = caviar;
		return this;
	}

	@Override
	public Hamburger cloneBurger() {
		return new RoyalHamburger(this);
	}
	
}
