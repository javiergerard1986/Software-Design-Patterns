package org.formacion.prototype.objects;

import org.formacion.prototype.enums.SIZE;
import org.formacion.prototype.enums.TOY;
import org.formacion.prototype.enums.BREAD;
import org.formacion.prototype.enums.CAVIAR;
import org.formacion.prototype.enums.MEAT;

public class Kitchen {

	public ChildHamburger createChildBurger() {
		return new ChildHamburger(MEAT.BOVINE, SIZE.SMALL, BREAD.NORMAL, TOY.BUZZ);
	}
	
	public RoyalHamburger createRoyalBurger(){
		return new RoyalHamburger(MEAT.CHIKEN, SIZE.BIG, BREAD.WITH_SEEDS, CAVIAR.BELUGA);
	}
	
}
