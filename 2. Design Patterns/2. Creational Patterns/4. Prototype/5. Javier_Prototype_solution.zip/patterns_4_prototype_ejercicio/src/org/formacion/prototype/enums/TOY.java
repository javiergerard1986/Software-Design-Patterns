package org.formacion.prototype.enums;

public enum TOY {
	BARBIE, BALL, BUZZ, PRINCESS
}
