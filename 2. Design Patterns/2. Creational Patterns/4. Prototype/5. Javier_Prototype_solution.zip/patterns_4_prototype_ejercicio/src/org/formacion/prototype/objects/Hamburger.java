package org.formacion.prototype.objects;

import org.formacion.prototype.enums.BREAD;
import org.formacion.prototype.enums.MEAT;
import org.formacion.prototype.enums.SIZE;

public abstract class Hamburger {
	
	protected MEAT meat;
	protected SIZE size;
	protected BREAD bread;
		
	public Hamburger() {}
	
	public Hamburger(MEAT meat, SIZE size, BREAD bread) {
		this.meat = meat;
		this.size = size;
		this.bread = bread;
	}
	
	public Hamburger(Hamburger target) {
		if(target != null) {
			this.meat = target.meat;
			this.size = target.size;
			this.bread = target.bread;
		}	
	}
	
	public MEAT getMeat() {
		return this.meat;
	}

	public Hamburger setMeat(MEAT meat) {
		this.meat = meat;
		return this;
	}

	public SIZE getSize() {
		return this.size;
	}

	public Hamburger setSize(SIZE size) {
		this.size = size;
		return this;
	}

	public BREAD getBread() {
		return this.bread;
	}

	public Hamburger setBread(BREAD bread) {
		this.bread = bread;
		return this;
	}

	public abstract Hamburger cloneBurger();
	
}
