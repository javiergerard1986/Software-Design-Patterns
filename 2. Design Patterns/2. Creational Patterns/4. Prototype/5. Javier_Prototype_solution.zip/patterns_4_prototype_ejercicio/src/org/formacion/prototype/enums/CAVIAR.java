package org.formacion.prototype.enums;

public enum CAVIAR {
	BELUGA, CARUGA
}
