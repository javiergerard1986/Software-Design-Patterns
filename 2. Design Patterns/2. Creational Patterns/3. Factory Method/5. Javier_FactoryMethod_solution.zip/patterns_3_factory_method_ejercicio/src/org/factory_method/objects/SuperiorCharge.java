package org.factory_method.objects;

import org.factory_method.enums.CHARGE_TYPE;

public class SuperiorCharge extends WashMachine {

    public SuperiorCharge() {
    	this.setChargeType(CHARGE_TYPE.SUPERIOR);
    }

	@Override
	public void setChargeType(CHARGE_TYPE chargeType) {
		this.chargeType = chargeType;		
	}
    
}
