package org.factory_method.objects;

import org.factory_method.enums.CHARGE_TYPE;

public abstract class WashMachine implements IWashMachine{

	protected boolean drum;
	protected boolean knows;
	protected CHARGE_TYPE chargeType;
	
	public void addDrum() {
		this.setDrum(true);
	}
	
	public void addKnows() {
		this.setKnows(true);
	}
	
	public void setDrum(boolean drum) {
		this.drum = drum;
	}
	
	public void setKnows(boolean knows) {
		this.knows = knows;
	}
	
	public boolean getDrum() {
		return this.drum;
	}
	
	public boolean getKnows() {
		return this.knows;
	}
	
	public CHARGE_TYPE getChargeType(){
		return this.chargeType;
	}

}
