package org.factory_method.objects;

import org.factory_method.enums.CHARGE_TYPE;

public class FrontalCharge extends WashMachine {

    public FrontalCharge() {
    	this.setChargeType(CHARGE_TYPE.FRONTAL);
    }

	@Override
	public void setChargeType(CHARGE_TYPE chargeType) {
		this.chargeType = chargeType;
	}
	
}
