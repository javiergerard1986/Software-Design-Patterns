package org.factory_method.enums;

public enum CHARGE_TYPE {
	SUPERIOR, FRONTAL
}
