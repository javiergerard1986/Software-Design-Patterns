package org.factory_method.factories;

import org.factory_method.objects.FrontalCharge;
import org.factory_method.objects.WashMachine;

public class FrontalChargeFactory extends WashMachineFactory{

	@Override
	public WashMachine create() {
		return new FrontalCharge();
	}

}
