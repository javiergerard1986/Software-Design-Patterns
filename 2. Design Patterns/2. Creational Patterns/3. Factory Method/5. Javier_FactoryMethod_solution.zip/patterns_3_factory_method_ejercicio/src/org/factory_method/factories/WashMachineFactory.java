package org.factory_method.factories;

import org.factory_method.objects.IWashMachine;
import org.factory_method.objects.WashMachine;

public abstract class WashMachineFactory {

	public IWashMachine createWashMachine() {
		
		IWashMachine washMachine = this.create();
		
		washMachine.addDrum();
		washMachine.addKnows();
		
		return washMachine;
		
	}

	public abstract WashMachine create();
	
}
