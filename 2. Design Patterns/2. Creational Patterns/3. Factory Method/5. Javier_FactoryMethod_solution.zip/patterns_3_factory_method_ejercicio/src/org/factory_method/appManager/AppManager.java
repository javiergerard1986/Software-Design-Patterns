package org.factory_method.appManager;

import org.factory_method.factories.FrontalChargeFactory;
import org.factory_method.factories.SuperiorChargeFactory;
import org.factory_method.factories.WashMachineFactory;

public class AppManager {

	public WashMachineFactory configure(String chargeType) throws Exception{
		switch(chargeType) {
			case("Frontal"):
				return new FrontalChargeFactory();
			case("Superior"):
				return new SuperiorChargeFactory();
			default:
				throw new Exception("A factory was not found with the provided option");
		}
		
	}
	
}
