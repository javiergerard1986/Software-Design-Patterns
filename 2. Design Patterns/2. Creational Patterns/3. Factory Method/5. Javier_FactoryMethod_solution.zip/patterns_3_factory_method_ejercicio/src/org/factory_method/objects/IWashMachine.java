package org.factory_method.objects;

import org.factory_method.enums.CHARGE_TYPE;

public interface IWashMachine {
	
	public void addDrum();
	
	public void addKnows();
	
	public void setChargeType(CHARGE_TYPE chargeType);
	
}
