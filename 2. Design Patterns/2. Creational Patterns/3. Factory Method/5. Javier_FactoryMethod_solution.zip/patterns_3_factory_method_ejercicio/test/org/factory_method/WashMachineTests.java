package org.factory_method;

import static org.junit.Assert.*;

import org.factory_method.appManager.AppManager;
import org.factory_method.enums.CHARGE_TYPE;
import org.factory_method.factories.WashMachineFactory;
import org.factory_method.objects.FrontalCharge;
import org.factory_method.objects.SuperiorCharge;
import org.junit.Test;

public class WashMachineTests {

	AppManager appManager = new AppManager();
	WashMachineFactory factory;
	
	@Test
	public void test_carga_frontal() {
		
		try {
			this.factory = this.appManager.configure("Frontal");
		} catch(Exception ex) {
			System.out.println("The application failed with the next error: " + ex.getMessage());
		}
		
		FrontalCharge frontalChargeWm = (FrontalCharge) factory.createWashMachine();
		
		assertTrue(frontalChargeWm.getDrum());
		assertTrue(frontalChargeWm.getKnows());
		assertEquals(frontalChargeWm.getChargeType(), CHARGE_TYPE.FRONTAL);
		
	}

	@Test
	public void test_carga_superior() {
		
		try {
			this.factory = this.appManager.configure("Superior");
		} catch(Exception ex) {
			System.out.println("The application failed with the next error: " + ex.getMessage());
		}
		
		SuperiorCharge superiorChargeWm = (SuperiorCharge)factory.createWashMachine();
		
		assertTrue(superiorChargeWm.getDrum());
		assertTrue(superiorChargeWm.getKnows());
		assertEquals(superiorChargeWm.getChargeType(), CHARGE_TYPE.SUPERIOR);
	}

}
