package org.builder.objects;

public class Adult extends Person{
	
	private String workPlace;

	public String getWorkPlace() {
		return workPlace;
	}

	public void setWorkPlace(String workPlace) {
		this.workPlace = workPlace;
	}

}
