package org.builder.builders;

public class Director {

	private IPersonBuilder builder;
	
	public Director() {}
	
	public Director(IPersonBuilder builder){
		this.setBuilder(builder);
	}
	
	public void setBuilder(IPersonBuilder builder) {
		this.builder = builder;
	}
	
	public void createAdult(AdultBuilder builder, String firstName, String lastName, int age, String municipality, String workPlace){
		builder.setFirstName(firstName);
		builder.setLastName(lastName);
		builder.setAge(age);
		builder.setMunicipality(municipality);
		builder.setWorkPlace(workPlace);
	}
	
	public void createChild(ChildBuilder builder, String firstName, String lastName, int age, String municipality, String school){
		builder.setFirstName(firstName);
		builder.setLastName(lastName);
		builder.setAge(age);
		builder.setMunicipality(municipality);
		builder.setSchool(school);
	}
	
	public void createLazyAdult(AdultBuilder builder, String firstName, String lastName, int age, String municipality) {
		builder.setFirstName(firstName);
		builder.setLastName(lastName);
		builder.setAge(19);
		builder.setMunicipality(municipality);
	}
	
	public void createPerson(String firstName, String lastName, String municipality){
		this.builder.setFirstName(firstName);
		this.builder.setLastName(lastName);
		this.builder.setMunicipality(municipality);
	}
	
}
