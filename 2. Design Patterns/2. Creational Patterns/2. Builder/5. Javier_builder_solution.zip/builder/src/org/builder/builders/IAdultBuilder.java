package org.builder.builders;

public interface IAdultBuilder extends IPersonBuilder{

	public void setWorkplace(String workPlace);
	
}
