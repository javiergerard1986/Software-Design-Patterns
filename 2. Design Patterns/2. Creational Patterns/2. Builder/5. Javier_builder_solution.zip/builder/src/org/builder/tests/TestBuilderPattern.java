package org.builder.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.builder.builders.AdultBuilder;
import org.builder.builders.ChildBuilder;
import org.builder.builders.Director;
import org.builder.objects.Adult;
import org.builder.objects.Child;
import org.builder.objects.Person;
import org.junit.jupiter.api.Test;

class TestBuilderPattern {

	Director director = new Director();
	
	@Test
	void test_builder_pattern_create_adult() {
		// Create required builder
		AdultBuilder builder = new AdultBuilder();
		// Request the director the creation of the object providing the specified director
		director.createAdult(builder, "Mario", "Suarez", 33, "Ciudad del Norte", "Codigo del Sur");
		// Obtain the created adult
		Adult adult = builder.build();
		
		assertNotNull(adult.getWorkPlace(), "Created adult must have a WorkPlace!");
		assertTrue(adult.getAge() >= 18, "Adult age must be higher than 17");
		
	}
	
	@Test
	void test_builder_pattern_create_child() {
		// Create required builder
		ChildBuilder builder = new ChildBuilder();
		// Request the director the creation of the object providing the specified director
		director.createChild(builder, "Benjamin", "Gutierrez", 13, "Ciudad del Sur", "Los Maristas");
		// Obtain the created child
		Child child = builder.build();
		
		assertNotNull(child.getSchool(), "Created child must have a school!");
		assertTrue(child.getAge() < 18, "Child age must be lower than 18");
		
	}
	
	@Test
	void test_builder_pattern_create_lazy_adult() {
		// Create required builder
		AdultBuilder builder = new AdultBuilder();
		// Request the director the creation of the object providing the specified director
		director.createLazyAdult(builder, "Alejandro", "Perez", 19, "San Andres");
		// Obtain the created adult
		Adult lazyAdult = builder.build();
		
		assertNull(lazyAdult.getWorkPlace(), "Created lazy adult must not have a WorkPlace!");
		assertTrue(lazyAdult.getAge() >= 18, "Adult age must be higher than 17");
		
	}
	
	@Test
	void test_builder_pattern_correct_use() {
		// Create required builder
		AdultBuilder aBuilder = new AdultBuilder();
		// Create director
		Director director = new Director(aBuilder);
		
		// Request the director the creation of the object providing the specified director
		director.createPerson("Pedro", "Moreira", "Las Tunas");
		// Obtain the created person
		Person aPerson = aBuilder.build();

		assertTrue(aPerson.getFirstName() == "Pedro", "First Name is not Pedro!");
		
		// Create required builder
		ChildBuilder cBuilder = new ChildBuilder();
		// Create director
		director.setBuilder(cBuilder);
		// Request the director the creation of the object providing the specified director
		director.createPerson("Rodrigo", "Torres", "Holguin");
		// Obtain the created person
		Person cPerson = cBuilder.build();
		
		assertTrue(cPerson.getFirstName() == "Rodrigo", "First Name is not Rodrigo!");
	}
	
}
