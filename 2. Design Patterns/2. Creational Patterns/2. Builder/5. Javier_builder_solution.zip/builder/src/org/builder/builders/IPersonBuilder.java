package org.builder.builders;

public abstract interface IPersonBuilder {
	
	void reset();

	void setFirstName(String firstName);
	
	void setLastName(String lastName);
	
	public void setAge(int age);
	
	public void setMunicipality(String municipality);
	
}
