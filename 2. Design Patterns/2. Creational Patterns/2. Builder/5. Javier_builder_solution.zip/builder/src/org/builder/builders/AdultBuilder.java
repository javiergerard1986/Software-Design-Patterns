package org.builder.builders;

import org.builder.objects.Adult;

public class AdultBuilder implements IPersonBuilder {
	
	private Adult adult;
	
	public AdultBuilder() {
		this.reset();
	}
	
	@Override
	public void setFirstName(String firstName) {
		this.adult.setFirstName(firstName);
	}
	
	@Override
	public void setLastName(String lastName) {
		this.adult.setLastName(lastName);
	}
	
	@Override
	public void setAge(int age) {
		this.adult.setAge(age);
	}
	
	@Override
	public void setMunicipality(String municipality) {
		this.adult.setMunicipality(municipality);
	}

	@Override
	public void reset() {
		this.adult = new Adult();
	}
	
	public void setWorkPlace(String workPlace) {
		this.adult.setWorkPlace(workPlace);
	}
	
	public Adult build() {
		return this.adult;
	}
	
}
