package org.builder.objects;

public abstract class Person {

	protected String firstName;
	protected String lastName;
	protected int age;
	protected String municipality;
	
	public void setFirstName(String firstName) {
		 this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		 this.lastName = lastName;
	}
	
	public void setAge(int age) {
		 this.age = age;
	}
	
	public void setMunicipality(String municipality) {
		 this.municipality = municipality;
	}
	
	public String getFirstName() {
		 return this.firstName;
	}
	
	public String getLastName() {
		 return this.lastName;
	}
	
	public int getAge() {
		 return this.age;
	}
	
	public String getMunicipality() {
		 return this.municipality;
	}
		
}
