package org.builder.builders;

import org.builder.objects.Child;

public class ChildBuilder implements IPersonBuilder {
	
	private Child child;
	
	public ChildBuilder() {
		this.reset();
	}
	
	@Override
	public void setFirstName(String firstName) {
		this.child.setFirstName(firstName);
	}
	
	@Override
	public void setLastName(String lastName) {
		this.child.setLastName(lastName);
	}
	
	@Override
	public void setAge(int age) {
		this.child.setAge(age);
	}
	
	@Override
	public void setMunicipality(String municipality) {
		this.child.setMunicipality(municipality);
	}

	@Override
	public void reset() {
		this.child = new Child();
	}
	
	public void setSchool(String school) {
		this.child.setSchool(school);
	}
	
	public Child build() {
		return this.child;
	}
	
}
