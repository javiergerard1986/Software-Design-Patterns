package org.abstractFactory.messages;

public class EnQuestions implements IQuestions {

	@Override
	public String askHour() {
		return "what time is it?";
	}

	@Override
	public String askWeather() {
		return "how is the weather?";
	}
	
}
