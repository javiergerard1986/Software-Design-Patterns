package org.abstractFactory.messages;

public class EnGreetings implements IGreetings{

	@Override
	public String goodMorning() {
		return "good morning";
	}

	@Override
	public String goodAfternoon() {
		return "good afternoon";
	}
	
}
