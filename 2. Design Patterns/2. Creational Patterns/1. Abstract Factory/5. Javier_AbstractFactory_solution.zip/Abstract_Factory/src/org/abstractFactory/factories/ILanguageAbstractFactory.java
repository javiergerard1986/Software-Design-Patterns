package org.abstractFactory.factories;

import org.abstractFactory.messages.IGreetings;
import org.abstractFactory.messages.IQuestions;

public interface ILanguageAbstractFactory {
	
	public IGreetings createGreetings();
	
	public IQuestions createQuestions();
	
}
