package org.abstractFactory.factories;

import org.abstractFactory.messages.EnGreetings;
import org.abstractFactory.messages.EnQuestions;

public class EnFactory implements ILanguageAbstractFactory{
	
	public EnGreetings createGreetings() {
		return new EnGreetings();
	}
	
	public EnQuestions createQuestions() {
		return new EnQuestions();
	}
	
}
