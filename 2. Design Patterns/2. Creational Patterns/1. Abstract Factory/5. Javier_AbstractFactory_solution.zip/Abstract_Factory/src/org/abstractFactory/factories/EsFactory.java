package org.abstractFactory.factories;

import org.abstractFactory.messages.EsGreetings;
import org.abstractFactory.messages.EsQuestions;

public class EsFactory implements ILanguageAbstractFactory{

	@Override
	public EsGreetings createGreetings() {
		return new EsGreetings();
	}

	@Override
	public EsQuestions createQuestions() {
		return new EsQuestions();
	}
	
}
