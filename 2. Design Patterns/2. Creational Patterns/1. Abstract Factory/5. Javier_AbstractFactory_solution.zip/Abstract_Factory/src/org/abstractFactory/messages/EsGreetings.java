package org.abstractFactory.messages;

public class EsGreetings implements IGreetings{

	@Override
	public String goodMorning() {
		return "buenos días";
	}

	@Override
	public String goodAfternoon() {
		return "buenas tardes";
	}
	
}
