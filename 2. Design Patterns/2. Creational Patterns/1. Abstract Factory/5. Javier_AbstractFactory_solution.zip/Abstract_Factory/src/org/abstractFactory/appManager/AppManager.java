package org.abstractFactory.appManager;

import org.abstractFactory.factories.EnFactory;
import org.abstractFactory.factories.EsFactory;
import org.abstractFactory.factories.ILanguageAbstractFactory;

public class AppManager {
	
	public ILanguageAbstractFactory getLanguageFactory(String language) throws Exception {
		
		switch(language) {
			case "ES":
				return new EsFactory();
			case "EN":
				return new EnFactory();
			default:
				throw new Exception("A language factory that matches with the provided: " + language + " language was not found");
		}
		
	}
	
}
