package org.abstractFactory.messages;

public interface IGreetings {

	String goodMorning();
	
	String goodAfternoon();
	
}
