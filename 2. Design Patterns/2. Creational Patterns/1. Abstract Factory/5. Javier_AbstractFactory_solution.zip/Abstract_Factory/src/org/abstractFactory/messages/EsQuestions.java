package org.abstractFactory.messages;

public class EsQuestions implements IQuestions{

	@Override
	public String askHour() {
		return "¿qué hora es?";
	}

	@Override
	public String askWeather() {
		return "¿qué tiempo hace?";
	}
	
}
