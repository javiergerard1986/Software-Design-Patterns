package org.abstractFactory.messages;

public interface IQuestions {

	String askHour();
	
	String askWeather();
	
}
