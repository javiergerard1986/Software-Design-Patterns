package org.abstractFactory.tests;

import static org.junit.Assert.*;
import org.abstractFactory.appManager.AppManager;
import org.abstractFactory.factories.ILanguageAbstractFactory;
import org.abstractFactory.messages.IGreetings;
import org.abstractFactory.messages.IQuestions;
import org.junit.Test;

public class TestMultiIdioma {

	AppManager appManager = new AppManager();
	ILanguageAbstractFactory languageFactory;
	IQuestions questions;
	IGreetings greetings;
	
	@Test
	public void test_es() {
		
		// Get Language Factory
		try {
			languageFactory = appManager.getLanguageFactory("ES");
		} catch(Exception ex) {
			System.out.println("Exception message: " + ex.getMessage());
		}
		
		// Get questions based on the defined Language Factory
		questions = languageFactory.createQuestions();
		
		assertEquals("¿qué hora es?", questions.askHour() );
		assertEquals("¿qué tiempo hace?", questions.askWeather());
		
		// Get greetings based on the defined Language Factory
		greetings = languageFactory.createGreetings();
		
		assertEquals("buenos días", greetings.goodMorning());
		assertEquals("buenas tardes", greetings.goodAfternoon());
	}
	
	@Test
	public void test_en() {
		
		// Get Language Factory
		try {
			languageFactory = appManager.getLanguageFactory("EN");
		} catch(Exception ex) {
			System.out.println("Exception message: " + ex.getMessage());
		}
		
		// Get questions based on the defined Language Factory
		questions = languageFactory.createQuestions();
		
		assertEquals("what time is it?", questions.askHour());
		assertEquals("how is the weather?", questions.askWeather());
		
		// Get greetings based on the defined Language Factory
		greetings = languageFactory.createGreetings();
		
		assertEquals("good morning", greetings.goodMorning());
		assertEquals("good afternoon", greetings.goodAfternoon());
	}

}
