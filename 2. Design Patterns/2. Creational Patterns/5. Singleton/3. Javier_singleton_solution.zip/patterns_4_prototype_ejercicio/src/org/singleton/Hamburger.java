package org.singleton;

public class Hamburger {

	private String meat;
	private String size;
	private String bread;
	
	public Hamburger(String meat, String size, String bread) {
		this.meat = meat;
		this.size = size;
		this.bread = bread;
	}

	public String getMeat() {
		return this.meat;
	}

	public String getSize() {
		return this.size;
	}

	public String getBread() {
		return this.bread;
	}
	
	public void setMeat(String meat) {
		this.meat = meat;
	}
	
	public void setSize(String size) {
		this.size = size;
	}
	
	public void setBread(String bread) {
		this.bread = bread;
	}
	
}
