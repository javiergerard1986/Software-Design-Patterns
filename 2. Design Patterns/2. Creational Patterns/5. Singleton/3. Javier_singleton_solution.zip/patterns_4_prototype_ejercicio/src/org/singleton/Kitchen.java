package org.singleton;

public class Kitchen {

	private static Kitchen INSTANCE;
	
	public synchronized static Kitchen getKitchen() {
		if(INSTANCE == null) {
			if(INSTANCE == null) {
				INSTANCE = new Kitchen();
			}
		}
		return INSTANCE;
	}
	
	public Hamburger getRoyalBurger() {
		return new Hamburger("Bovine", "Medium", "With Seeds");
	}

	public Hamburger getKingBurger() {
		return new Hamburger("Chiken", "Big", "Normal");
	}

}
