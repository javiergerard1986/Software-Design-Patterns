package org.singleton.tests;

import static org.junit.Assert.*;

import org.junit.Test;
import org.singleton.Hamburger;
import org.singleton.Kitchen;

public class SingletonTests {

	private Kitchen kitchen = Kitchen.getKitchen();
	
	@Test
	public void test_carta() {
		Hamburger royal = kitchen.getKingBurger();

		assertEquals("Chiken", royal.getMeat());
		assertEquals("Big", royal.getSize());
		assertEquals("Normal", royal.getBread());
	}

}
